module.exports = {
  reactStrictMode: true,
  swcMinify: true
}
